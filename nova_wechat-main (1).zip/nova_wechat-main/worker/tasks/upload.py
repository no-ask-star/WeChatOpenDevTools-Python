import sqlite3

from nova_celery import app
from db.decrepty.decrypt import decrypt_entrance
from db.decrepty.load_wx_info import get_wxid
from utils import MERGE_DB_PATH
from utils.client import ServerClient
from utils.db import fetch_cursor_as_record
from worker.action.chat_room import logger


@app.task
def task_upload_message(message: dict):
    print(ServerClient().upload_message(message))


@app.task
def task_upload_file(file_path: str, data: dict):
    ServerClient().upload_file(file_path, data) 


@app.task
def task_upload_chat_room(chat_room: dict):
    ServerClient().upload_chat_room(chat_room)  


@app.task
def task_join_room_event(data: dict):
    ServerClient().join_room_event(data)


@app.task
def add(a, b):
    return a + b


@app.task
def sync_chat_room_info():
    decrypt_entrance()
    conn = sqlite3.connect(MERGE_DB_PATH)
    try:
        contact_sql = f"""
        SELECT
            ChatRoomName as room_id,
            UserNameList as user_list,
            NickName as nick_name,
            ContactHeadImgUrl.smallHeadImgUrl as head_url
        FROM ChatRoom
        INNER JOIN Contact
        INNER JOIN ContactHeadImgUrl
        ON ChatRoom.ChatRoomName = Contact.UserName
        AND ChatRoom.ChatRoomName = ContactHeadImgUrl.usrName
        WHERE UserNameList != ""
        """

        contact_cursor = conn.execute(contact_sql)
        contact_records = fetch_cursor_as_record(contact_cursor)
        task_upload_chat_room.delay(chat_room={
            'action': contact_records,
            'robot_wx_id': get_wxid()
        })
        return {
             'action': contact_records,
             'robot_wx_id': get_wxid()
         }

    except Exception as e:
        logger.error(e)
    finally:
        conn.close()


@app.task
def task_sync_chat_room():
    decrypt_entrance()
    sync_chat_room_info()
