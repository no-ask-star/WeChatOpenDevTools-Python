import sqlite3

from db.decrepty.decrypt import decrypt_entrance
from utils import MERGE_DB_PATH
from utils.logger import get_logger
from utils.db import fetch_cursor_as_record

logger = get_logger(__name__)


def get_wxid_by_nickname_in_room(room_id, nickname):
    room_info_sql = f"""
    SELECT
        ChatRoomName as room_id,
        UserNameList as user_list
    FROM ChatRoom
    WHERE  ChatRoom.ChatRoomName='{room_id}';
    """
    conn = sqlite3.connect(MERGE_DB_PATH)
    room_info_cursor = conn.execute(room_info_sql)
    room_info = fetch_cursor_as_record(room_info_cursor)[0]
    user_list = room_info['user_list'].split("^G")

    nickname_list_sql = f"""
    SELECT UserName, Alias, NickName
    FROM Contact
    WHERE UserName IN ('{"','".join(user_list)}');
    """
    print(nickname_list_sql)
    nickname_list_cursor = conn.execute(nickname_list_sql)
    nickname_list = fetch_cursor_as_record(nickname_list_cursor)
    name_id_map = {
        item['NickName']: item['Alias'] if item['Alias'] else item['UserName']
        for item in nickname_list
    }
    print(name_id_map)
    return name_id_map[nickname]




# if __name__ == '__main__':
    # decrypt_entrance()

    # get_wxid_by_nickname_in_room("57559489392@chatroom", "不问散人")