import os
import platform
import sys
import getopt


if __name__ == '__main__':

    _opts, _args = getopt.getopt(sys.argv[1:], 'l')
    mode = 'INFO' if len(_args) == 0 else _args[0]
    print('Running mode: %s' % mode)
    os.chdir(os.path.dirname(__file__))
    cmd = 'python -m celery -A nova_celery  worker -l %s -c 1 ' % mode

    if platform.system().lower() == 'windows':
        cmd += '-P solo'

    os.system(cmd)
