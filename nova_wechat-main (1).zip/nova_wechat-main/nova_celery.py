from datetime import timedelta
import logging

from celery import Celery
from celery.signals import after_setup_task_logger, after_setup_logger


@after_setup_logger.connect
@after_setup_task_logger.connect
def setup_loggers(logger, **kwargs):
    formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(name)s [line:%(lineno)d] %(message)s')

    fh = logging.FileHandler('./celery_log', encoding='utf-8')
    fh.setFormatter(formatter)
    logger.addHandler(fh)


app = Celery('nova', broker='redis://127.0.0.1:16379/5', backend='redis://127.0.0.1:16379/6')

app.conf.task_serializer = 'json'
app.conf.result_serializer = 'json'

app.conf.enable_utc = True
app.conf.timezone = 'Asia/Shanghai'


app.conf.beat_schedule = {
    'task_sync_chat_room': {
        'task': 'worker.tasks.scheduler.task_sync_chat_room',
        'schedule': timedelta(minutes=3),
    },
}
app.conf.update(
    broker_connection_retry_on_startup=True
)

app.autodiscover_tasks(['worker.tasks'])

if __name__ == '__main__':
    app.start()
