import datetime
import json
import logging
import os.path
import re
import time
from dataclasses import asdict

from wxhook import Bot
from wxhook.model import Event

from db.decrepty.load_wx_info import get_wxid
from utils.download import download_attachment_with_retry
from worker.action.chat_room import get_wxid_by_nickname_in_room
from worker.tasks import sync_chat_room_info
import xmltodict

from utils.decode_image import decode_image, download_image
from worker.tasks.upload import task_upload_file, task_upload_message, add, task_join_room_event

db_info = None

logger = logging.getLogger()

# 设置日志的默认级别
logger.setLevel(logging.WARNING)  # 只显示 warning 或更高严重性的日志


def get_db_info(bot: Bot):
    global db_info

    if db_info is None:
        db_info_tmp = bot.call_api("/api/getDBInfo")
        print(db_info_tmp)

        db_info = {
            item['databaseName']: item['handle']
            for item in db_info_tmp['data']
        }
    return db_info


def get_user_chatroom_nickname(bot: Bot, wx_id: str, room_id: str):
    db_handler = get_db_info(bot).get('MicroMsg.db')
    ans = bot.exec_sql(db_handle=db_handler, sql=f"""
        SELECT
            UserNameList as user_list,
            DisplayNameList as display_list
        FROM ChatRoom
        WHERE ChatRoomName='{room_id}'
    """)
    user_list, display_list = ans.data[1]
    id_name_map = dict(zip(user_list.split("^G"), display_list.split("^G")))
    nickname = id_name_map.get(wx_id)
    if not nickname:
        nickname = bot.get_contact(wx_id).nickname
    return nickname


def get_xml_dict(content) -> dict:
    if isinstance(content, str):
        # sender, xml_str = content.split(":", 1)
        cleaned_xml_str = content.replace('\"', '"').replace('\n', '').replace('\t', '')
        content_dict = xmltodict.parse(cleaned_xml_str)
    elif isinstance(content, dict):
        content_dict = content
    else:
        content_dict = dict()
    return content_dict


def is_file_message(event: Event) -> bool:
    clean_content = get_xml_dict(event.content)

    return clean_content['msg']['appmsg']['type'] == '6'


def is_merge_forward_message(event: Event) -> bool:
    clean_content = get_xml_dict(event.content)

    return clean_content['msg']['appmsg']['type'] == '19'


def is_quote_message(event: Event) -> bool:
    clean_content = get_xml_dict(event.content)
    return clean_content['msg']['appmsg']['type'] == '57'


def is_group_msg(event: Event) -> bool:
    return '@chatroom' in event.fromUser


def is_private_msg(event: Event) -> bool:
    return event.fromUser.startswith("wxid_")


def download_and_upload_file(bot: Bot, msg_id: int, sender_id: str, filename: str, upload_msg_id: int = None):
    response = bot.download_attachment(msg_id)
    assert response.code == 0, f"下载文件失败， 消息id为 {msg_id}, {response.msg}"
    file_abs_path = os.path.join(bot.FILE_SAVE_PATH, f"{msg_id}_{filename}")

    download_success = download_attachment_with_retry(
        bot=bot,
        attachment_id=msg_id,
        file_abs_path=file_abs_path
    )
    if download_success:
        data = {
            'msg_id': msg_id if not upload_msg_id else upload_msg_id,
            'sender': bot.get_contact(wxid=sender_id).account,
        }
        task_upload_file.delay(file_abs_path, data=data)
    else:
        print("下载失败")


def process_file_message(bot: Bot, event: Event):
    try:
        content = event.content
        filename = content['msg']['appmsg']['title']
        if is_private_msg(event):
            process_text_message(bot, event)
            download_and_upload_file(
                bot=bot,
                msg_id=event.msgId,
                sender_id=event.fromUser,
                filename=filename
            )

    except Exception as e:
        logger.error(e)


def process_from_xml(bot: Bot, record_items: dict | str, from_user: str, root_msg_id: int):
    record_items = get_xml_dict(record_items)
    for item in record_items['recordinfo']['datalist']['dataitem']:
        if item.get('datafmt'):
            msg_id = item['fromnewmsgid']
            filename = item['datatitle']
            download_and_upload_file(
                bot=bot,
                msg_id=msg_id,
                sender_id=from_user,
                filename=filename,
                upload_msg_id=root_msg_id
            )
        if item.get('recordxml'):
            process_from_xml(bot, item['recordxml'], from_user, root_msg_id)


def upload_merge_forward_file(bot: Bot, event: Event):
    content = get_xml_dict(event.content)
    process_from_xml(bot=bot, record_items=content['msg']['appmsg']['recorditem'], from_user=event.fromUser,
                     root_msg_id=event.msgId)


def process_text_message(bot: Bot, event: Event):
    event_dict = asdict(event)
    # 群组消息
    if is_group_msg(event):
        content: str = event.content
        actual_from_user, content = content.split(':', 1)
        room_info = bot.get_contact(event.fromUser)
        user_info = bot.get_contact(actual_from_user)
        user_info.nickname = get_user_chatroom_nickname(bot, actual_from_user, event.fromUser)
        event_dict['from_user'] = actual_from_user
        event_dict['user_info'] = asdict(user_info)

        event_dict['content'] = content
        event_dict['room_info'] = asdict(room_info)
        event_dict['is_room'] = True
        with open('../x.json', 'w', encoding='utf-8') as f:
            f.write(json.dumps(event_dict, ensure_ascii=False))
    # 私聊消息
    elif is_private_msg(event):
        user_info = bot.get_contact(event.fromUser)
        if not user_info.account:
            user_info.account = event.fromUser
        event_dict['user_info'] = asdict(user_info)
        event_dict['is_room'] = False
    task_upload_message.delay(message=event_dict)


def process_image_message(bot: Bot, event: Event):
    if is_private_msg(event):
        # upload message
        event.content = event.signature['msgsource'].get(
            'img_file_name',
            f'微信图片_{datetime.datetime.now().strftime("%y%m%d%H%M%S")}.jpg'
        )
        process_text_message(bot, event)

        image_path = os.path.join(bot.IMAGE_SAVE_PATH, f"{event.msgId}.dat")
        download_success = download_attachment_with_retry(
            bot=bot,
            attachment_id=event.msgId,
            file_abs_path=image_path
        )
        if download_success:
            image_output_path = os.path.join(bot.IMAGE_SAVE_PATH, f"decode/{event.content}")
            decode_image(image_path, image_output_path)
            data = {
                'msg_id': event.msgId,
                'sender': bot.get_contact(wxid=event.fromUser).account,
            }
            task_upload_file.delay(image_output_path, data=data)
        else:
            print("下载失败")


def process_notice_message(bot: Bot, event: Event):
    sync_chat_room_info()
    join_group_flag = "邀请你加入了群聊，群聊参与人还有"
    if join_group_flag in event.content:
        event_dict = asdict(event)
        content = event.content
        inviter = re.match('"(.*)"', content).group(1)
        inviter_wx_account = get_wxid_by_nickname_in_room(event.fromUser, inviter)
        room_members = bot.get_room_members(room_id=event.fromUser)
        room_info = bot.get_contact(event.fromUser)
        event_dict['inviter_wx_account'] = inviter_wx_account
        event_dict['room_members'] = asdict(room_members)
        event_dict['inviter'] = inviter
        event_dict['room_info'] = asdict(room_info)
        event_dict['is_room'] = True
        event_dict['robot_wx_id'] = get_wxid()
        task_join_room_event.delay(action=event_dict)
