import json
from dataclasses import asdict

from wxhook import Bot
from wxhook import events
from wxhook.model import Event

from pymem import Pymem

from nova_celery import app
from core.bot.action import process_file_message, is_file_message, process_text_message, is_merge_forward_message, \
    upload_merge_forward_file, is_quote_message, process_image_message, process_notice_message, get_db_info


def fix_version(pm: Pymem):
    WeChatWindll_base = 0
    for m in list(pm.list_modules()):
        path = m.filename
        if path.endswith("WeChatWin.dll"):
            WeChatWindll_base = m.lpBaseOfDll
            break

    # 这些是CE找到的标绿的内存地址偏移量
    ADDRS = [0x3A70FD4, 0x3A878DC, 0x3AA0508, 0x3AC85F0, 0x3ACF3D8, 0x3AD1908]

    for offset in ADDRS:
        addr = WeChatWindll_base + offset
        v = pm.read_uint(addr)
        if v != 0x63090551:
            continue
        pm.write_uint(addr, 0x63090b19)  # 改成要伪装的版本3.9.11.25，

    print("版本伪装成功，可以确认登录")


def on_login(bot: Bot, event: Event):
    # print("登录成功之后会触发这个函数")
    pass


def on_start(bot: Bot):
    try:
        pm = Pymem("WeChat.exe")
        fix_version(pm)
    except Exception as e:
        print(f"{e}，请确认微信程序已经打开！")
    pass


def on_stop(bot: Bot):
    # print("关闭微信客户端之前会触发这个函数")
    pass


def on_before_message(bot: Bot, event: Event):
    # print("消息事件处理之前")
    pass


def on_after_message(bot: Bot, event: Event):
    pass


def start_bot():
    bot = Bot(
        faked_version="3.9.10.19",  # 解除微信低版本限制
        on_login=on_login,
        on_start=on_start,
        on_stop=on_stop,
        on_before_message=on_before_message,
        on_after_message=on_after_message
    )

    @bot.handle(
        [events.XML_MESSAGE, events.TEXT_MESSAGE, events.VOICE_MESSAGE, events.IMAGE_MESSAGE, events.NOTICE_MESSAGE, events.VIDEO_MESSAGE])
    def on_message(bot: Bot, event: Event):
        # print(get_db_info(bot))

        with open('../ss.json', 'w') as f:

            f.write(json.dumps(asdict(event)))

        if event.type == events.XML_MESSAGE:
            if is_file_message(event):
                process_file_message(bot, event)
            elif is_merge_forward_message(event):
                process_text_message(bot, event)
                upload_merge_forward_file(bot, event)
            elif is_quote_message(event):
                process_text_message(bot, event)
        elif event.type == events.TEXT_MESSAGE:
            process_text_message(bot, event)
        elif event.type == events.IMAGE_MESSAGE:
            process_image_message(bot, event)
        elif event.type == events.NOTICE_MESSAGE:
            process_notice_message(bot, event)
        else:
            pass

    bot.run()



if __name__ == '__main__':
    start_bot()

