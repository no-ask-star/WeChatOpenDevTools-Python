from worker.tasks.upload import add
import logging
from nova_celery import app


# 获取日志记录器
logger = logging.getLogger()

# 设置日志的默认级别
logger.setLevel(logging.WARNING)  # 只显示 warning 或更高严重性的日志

if __name__ == '__main__':
    print(add.delay(1, 2))