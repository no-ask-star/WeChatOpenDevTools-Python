import json
import os
from json import JSONDecodeError

from utils import WX_INFO_PATH
from utils.logger import get_logger

logger = get_logger(__file__)


def load_wx_info():
    if not os.path.exists(WX_INFO_PATH):
        logger.error(f"get wx_info failed， path {WX_INFO_PATH} NOT found")
        raise FileNotFoundError(WX_INFO_PATH)

    with open(WX_INFO_PATH, 'r') as f:
        wx_info_str = f.read()
        try:
            wx_info = json.loads(wx_info_str)
            return wx_info
        except JSONDecodeError as e:
            logger.error(f"load wx info error, expect json object, get {wx_info_str}\n{e}")
            return None


WX_INFO = load_wx_info()


def get_wx_file_path():
    if WX_INFO:
        return WX_INFO['filePath']


def get_wxid():
    if WX_INFO:
        return WX_INFO['wxid']


def get_wx_key():
    if WX_INFO:
        return WX_INFO['key']
