import os
import ctypes
import sqlite3
from pathlib import Path

from db.decrepty.merge_db import merge_sqlite_entrance
from utils import ROOT_DIR, DECRYPT_FILE_DIR, CRYPT_FILE_DIR, MERGE_DB_PATH
from db.decrepty.load_wx_info import get_wx_key, get_wx_file_path
from utils.file import copy_files, find_db_files, delete_dir_files
from utils.logger import get_logger

logger = get_logger(__name__)

DECRYPT_DB = [
    "ChatRoomUser",
    "Emotion",
    "HardLinkFile",
    "HardLinkImage",
    "MSG0",
    "MicroMsg",
    "OpenIMContact",
    "ChatRoom",
    "ChatRoomInfo",
    "Misc"
]


def merge_wal_to_sqlite(file_path):
    logger.info("merging wal to sqlite")
    if not isinstance(file_path, str):
        file_path = str(file_path)
    db_list = find_db_files(file_path)
    for db_path in db_list:
        wal_path = db_path + "-wal"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # 查询WAL状态
        cursor.execute("PRAGMA journal_mode = WAL")
        cursor.execute("PRAGMA wal_autocheckpoint = 0")
        cursor.execute("PRAGMA wal_checkpoint(RESTART)")

        conn.close()

        # wal_file_size = os.path.getsize(wal_path)
        # print(f"{wal_path} 文件大小: {wal_file_size} 字节")
    logger.info("merge wal succeeded")


def rename_decrypt_db_files(decrypt_file_dir):
    file_list = os.listdir(decrypt_file_dir)
    for file in file_list:
        old_file_path = os.path.join(decrypt_file_dir, file)
        new_file_path = os.path.join(decrypt_file_dir, file.replace("decrypted_", ""))
        os.rename(old_file_path, new_file_path)


def decrypt(origin_db_dir, decrypt_path, merge_db_path):
    # 加载生成的 DLL
    hex_key = get_wx_key()
    key = bytes.fromhex(hex_key)
    dll_path = os.path.abspath(f"{ROOT_DIR}/lib/decrypt.dll")
    rust_lib = ctypes.CDLL(dll_path)

    # 定义 decrypt 函数的参数和返回值类型
    rust_lib.decrypt.argtypes = [
        ctypes.c_char_p,  # save_path_str
        ctypes.c_char_p,  # decrypt_path_str
        ctypes.POINTER(ctypes.c_ubyte),  # key
        ctypes.c_size_t,  # key_len
        ctypes.c_bool  # need_check_hmac
    ]
    rust_lib.decrypt.restype = ctypes.c_int  # Return type

    # Convert the key to ctypes.POINTER(ctypes.c_ubyte)
    key_array = (ctypes.c_ubyte * len(key)).from_buffer_copy(key)
    key_ptr = ctypes.cast(key_array, ctypes.POINTER(ctypes.c_ubyte))

    need_check_hmac = False

    # Call the decrypt function
    origin_db_dir_bytes = origin_db_dir.encode('utf-8') if isinstance(origin_db_dir, str) else origin_db_dir
    decrypt_path_bytes = decrypt_path.encode('utf-8') if isinstance(decrypt_path, str) else decrypt_path
    result = rust_lib.decrypt(origin_db_dir_bytes, decrypt_path_bytes, key_ptr, len(key), need_check_hmac)

    # 检查返回值
    if result == 0:
        logger.info("Decryption succeeded.")
        merge_wal_to_sqlite(decrypt_path)
        rename_decrypt_db_files(decrypt_path)
        merge_sqlite_entrance(origin_db_dir, decrypt_path, merge_db_path)
    else:
        logger.error(f"Decryption failed with error code: {result}")
    return result


def decrypt_entrance():
    wx_file_path = Path(get_wx_file_path()) / 'MSG'
    delete_dir_files(DECRYPT_FILE_DIR)
    delete_dir_files(CRYPT_FILE_DIR)
    copy_files(str(wx_file_path), str(CRYPT_FILE_DIR), copy_file_list=DECRYPT_DB)
    decrypt(CRYPT_FILE_DIR, DECRYPT_FILE_DIR, MERGE_DB_PATH)


if __name__ == '__main__':
    decrypt_entrance()
