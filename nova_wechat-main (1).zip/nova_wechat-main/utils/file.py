import shutil
import os


def delete_dir_files(dir_path):
    if os.path.exists(dir_path):
        # 遍历目标目录中的所有项并删除
        for item in os.listdir(dir_path):
            item_path = os.path.join(dir_path, item)
            if os.path.isfile(item_path) or os.path.islink(item_path):
                os.unlink(item_path)  # 删除文件或链接
            else:
                shutil.rmtree(item_path)  # 删除目录


def copy_files(src_dir: str, dst_dir: str, copy_file_list=None):
    delete_dir_files(dst_dir)
    # 检查源目录是否存在
    if not os.path.exists(src_dir):
        print(f"源目录不存在: {src_dir}")
        return

    # 创建目标目录，如果它不存在的话
    if not os.path.exists(dst_dir):
        os.makedirs(dst_dir)

    # 遍历源目录
    for root, dirs, files in os.walk(src_dir):
        for file in files:
            filename = file.split('.')[0]
            if (copy_file_list and filename in copy_file_list) or not copy_file_list:
                src_file = os.path.join(root, file)
                dst_file = os.path.join(dst_dir, file)

                os.makedirs(os.path.dirname(dst_file), exist_ok=True)
                shutil.copy2(src_file, dst_file)
                print(f"已复制: {src_file} -> {dst_file}")


def find_db_files(directory):
    db_files = []
    # 遍历目录下的所有文件和文件夹
    for root, dirs, files in os.walk(directory):
        for file in files:
            # 检查文件后缀是否为.db
            if file.endswith('.db'):
                db_files.append(os.path.join(root, file))
    return db_files
