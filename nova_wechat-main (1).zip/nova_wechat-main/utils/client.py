import enum
import os

import requests

from .config import get_config


class ServerUrl(str, enum.Enum):
    UPLOAD_FILE = 'api/internal/wx/file/'
    UPLOAD_MESSAGE = 'api/internal/wx/message/'
    UPLOAD_CHAT_ROOM = 'api/internal/wx/chat_room/'
    ROBOT_JOIN_ROOM = 'api/internal/wx/join-room'
    DOWNLOAD_ERROR = 'api/internal/wx/download-attachment-error/'


class ServerClient:
    @classmethod
    def post(cls, url, *args, **kwargs):
        config = get_config()
        base_url = config['wechat']['base_url']
        token = config['wechat']['token']
        url = os.path.join(base_url, url)
        return requests.post(url, headers={
            'authorization': token
        }, *args, **kwargs)

    @classmethod
    def upload_message(cls, message: dict):
        return (cls.post(
            url=ServerUrl.UPLOAD_MESSAGE,
            json=message
        )
    )

    @classmethod
    def join_room_event(cls, data: dict):
        return cls.post(
            url=ServerUrl.ROBOT_JOIN_ROOM,
            json=data
        )

    @classmethod
    def upload_file(cls, file_path: str, data: dict):
        with open(file_path, 'rb') as f:
            files = {'file': (file_path, f)}
            return cls.post(ServerUrl.UPLOAD_FILE, files=files, data=data)

    @classmethod
    def upload_chat_room(cls, chat_room: dict):
        return cls.post(
            url=ServerUrl.UPLOAD_CHAT_ROOM,
            json=chat_room
        )

    @classmethod
    def report_download_error(cls, sender_id, attachment_name):
        return cls.post(
            url=ServerUrl.DOWNLOAD_ERROR,
            json={
                "sender_id": sender_id,
                "attachment_name": attachment_name
            }
        )
