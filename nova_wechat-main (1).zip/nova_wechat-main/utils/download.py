import os

from wxhook import Bot
import time

import time  # 如果文件中尚未导入time模块，请确保导入


# ... 其它代码保持不变

def download_attachment_with_retry(
        bot: Bot,
        attachment_id: int,
        file_abs_path: str,
        wait_seconds: int = 3 * 60
):

    current_wait = 5
    start_time = time.time()

    while True:
        bot.download_attachment(attachment_id)
        if os.path.exists(file_abs_path):
            return True

        current_time = time.time() - start_time
        if current_time > wait_seconds:
            break
        time.sleep(current_wait)
    return False
