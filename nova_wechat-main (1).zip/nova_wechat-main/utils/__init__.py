import os
import os
from pathlib import Path


ROOT_DIR = Path(__file__).resolve().parent.parent

WX_INFO_PATH = ROOT_DIR / 'wx/wx_info.txt'

CRYPT_FILE_DIR = os.path.join(str(ROOT_DIR), 'action/crypt')
DECRYPT_FILE_DIR = os.path.join(str(ROOT_DIR), 'action/decrypt')
MERGE_DB_PATH = os.path.join(str(ROOT_DIR), 'action/merge.db')
UPLOAD_PATH = os.path.join(str(ROOT_DIR), 'action/upload')
