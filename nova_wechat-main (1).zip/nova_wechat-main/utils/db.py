def fetch_cursor_as_record(cursor) -> list[dict]:
    column_names = [description[0] for description in cursor.description]
    # 获取所有结果行，并转换成字段名和值的字典格式
    result = [dict(zip(column_names, row)) for row in cursor.fetchall()]
    return result
