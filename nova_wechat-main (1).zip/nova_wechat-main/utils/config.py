import configparser
import os

from utils import ROOT_DIR

config = None


def get_config() -> configparser.ConfigParser:
    global config
    if not config:
        config_path = ROOT_DIR / "config.ini"
        config = configparser.ConfigParser()
        config.read(config_path)
    return config


if __name__ == '__main__':
    config = get_config()
    print(config['wechat']['base_url'])