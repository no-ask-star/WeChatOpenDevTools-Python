# weixin_Image.dat 破解
# JPG 16进制 FF D8 FF
# PNG 16进制 89 50 4e 47
# GIF 16进制 47 49 46 38
# 微信.bat 16进制 a1 86----->jpg  ab 8c----jpg     dd 04 --->png
# 自动计算异或 值
import os
import time

from wxhook import Bot
from wxhook.model import Event


def download_image(bot: Bot, event: Event, dat_path: str):
    print(dat_path)
    bot.download_attachment(event.msgId)
    max_sleep_times = 10
    download_success = False
    while max_sleep_times > 0:
        if os.path.exists(dat_path):
            download_success = True
            break
        else:
            time.sleep(1)
            max_sleep_times -= 1
    return download_success


def decode_image(image_abs_path, image_output_path):
    print("开始解密")
    with open(image_abs_path, 'rb') as dat_read:
        with open(image_output_path, 'wb') as dat_write:
            xo = image_format(image_abs_path)  # 判断图片格式 并计算返回异或值
            dat_read.seek(0)  # 重置文件指针位置

            for now in dat_read:  # 循环字节
                for nowByte in now:
                    new_byte = nowByte ^ xo  # 转码计算
                    dat_write.write(bytes([new_byte]))  # 转码后重新写入

    return image_output_path


def image_format(image_path):
    """
    计算异或值
    各图片头部信息
    jpeg：ff d8 ff
    png：89 50 4e 47
    gif： 47 49 46 38
        """
    dat_r = open(image_path, "rb")
    try:
        a = [(0x89, 0x50, 0x4e), (0x47, 0x49, 0x46), (0xff, 0xd8, 0xff)]
        for now in dat_r:
            for xor in a:
                i = 0
                res = []
                nowg = now[:3]  # 取前三个 数据信息
                for nowByte in nowg:
                    res.append(nowByte ^ xor[i])  # 进行判断
                    i += 1
                if res[0] == res[1] == res[2]:  # 三次异或值想等 说明就是那种格式
                    return res[0]  # 返回异或值
    except:
        pass
    finally:
        dat_r.close()


if __name__ == '__main__':
    decode_image(r"C:\Users\74374\Documents\WeChat Files\wxid_vpurrtkw8xr522\wxhelper\image\4096422643568833353.dat",
                 "./test.jpg")
