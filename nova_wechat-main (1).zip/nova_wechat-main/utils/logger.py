import logging

logging.getLogger("comtypes").setLevel(logging.CRITICAL)


def get_logger(name):
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s-%(filename)s-%(levelname)s: %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    logger = logging.getLogger(name)
    return logger
